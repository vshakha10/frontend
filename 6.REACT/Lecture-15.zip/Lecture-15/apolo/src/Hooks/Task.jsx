// const Task = () => {
//   const initialState1 = { value: 20 };
//   const initialState2 = { value: 20, data: 30 };
//   const initialState3 = [{ value: 20 }];
//   const initialState4 = [{ value: 20, data: 30 }];


