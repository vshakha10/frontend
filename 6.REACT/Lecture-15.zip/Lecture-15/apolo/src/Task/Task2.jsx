import React from "react";
import {useState} from "react";

function Task2() {
  const [state, setState] = useState({ value: 20, data: 30 });

  const IncrementValue = () =>
    setState((prevState) => ({ ...prevState, value: prevState.value + 1 }));

  const DecrementValue = () =>
    setState((prevState) => ({ ...prevState, value: prevState.value - 1 }));

  const IncrementData = () =>
    setState((prevState) => ({ ...prevState, data: prevState.data + 1 }));

  const DecrementData = () =>
    setState((prevState) => ({ ...prevState, data: prevState.data - 1 }));

  return (
    <div>
        <h1>Task 2</h1>
      <h1>Value: {state.value}</h1>
      <h1>Data: {state.data}</h1>

      <button onClick={IncrementValue}>Increment Value</button>
      <button onClick={DecrementValue}>Decrement Value</button>

      <button onClick={IncrementData}>Increment Data</button>
      <button onClick={DecrementData}>Decrement Data</button>
    </div>
  );
}

export default Task2;
