import React, { useState } from "react";

function Task4() {
  const [state, setState] = useState([{ value: 20, data: 30 }]);

  const updateValues = () => {
    setState([{ value: 50, data: 60 }]);
  };

  return (
    <div>
        <h1>Task 4</h1>
      <p>Value: {state[0].value}</p>
      <p>Data: {state[0].data}</p>
      <button onClick={updateValues}>Update Values</button>
    </div>
  );
}

export default Task4;
