import React, { useState } from "react";


  const Task3 = () => {
    const [state, setState] = useState([{ value: 20 }]);

    const updateValue = () => {
      setState([{ value: 30 }]);
    };
    return (
      <div>
        <h1>Task 3</h1>
        <p>Current value: {state[0].value}</p>
        <button onClick={updateValue}>Update Value</button>
      </div>
    );
  };


export default Task3;
