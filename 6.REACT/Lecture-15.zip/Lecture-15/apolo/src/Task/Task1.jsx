import { useState } from "react";

function Task1() {
  const [value, setValue] = useState(20);

  const Increment = () => setValue(value + 1);
  const Decrement = () => setValue(value - 1);

  return (
    <div>
    <h1>Task 1</h1>
      <h1>Value:{value}</h1>
      <button onClick={Increment}>Increment</button>
      <button onClick={Decrement}>Decrement</button>
    </div>
  );
}

export default Task1;
